// This file is kept for compatibility but functionality is disabled
export function initRC() {
  // Do nothing - payments are disabled
  console.log('Payment system is disabled - free mode is active');
}